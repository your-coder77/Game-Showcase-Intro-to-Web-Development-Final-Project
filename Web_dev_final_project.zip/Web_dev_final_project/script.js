// Grab elements with the class
var message = document.getElementsByClassName("card_info");

// Constructor for your game data
function Fields(price, platform, release_date, Basic_Edition, Ultimate_Edition,why) {
  this.price = price;
  this.platform = platform;
  this.release_date = release_date;
  this.Basic_Edition = Basic_Edition;
  this.Ultimate_Edition = Ultimate_Edition;
  this.why = why;
}

// Create placeholders for now (you can fill with real info later)
const games = [
  new Fields("TBD ", " PC, Nintendo Switch,", "  Spring 2026","  TBD"," TBD", " Legacy of the Dark Knight is an upcoming open-world action-adventure game developed by TT Games, set for a 2026 release across current-generation consoles and PC, featuring a darker original storyline and connectivity with physical LEGO sets."), //batman lego

  new Fields("$69.99 ", " PlayStation 5,  Xbox Series X/S, Windows (PC), and Nintendo Switch 2", "  March 27, 2026 ", "$69.99", "$300", "Follow James Bond as a young, resourceful, and sometimes reckless recruit in MI6's training program, and discover an origin story of the world's most famous spy."), //first light

  
  new Fields("$69.99 or $70", "Switch, PS 5, Xbox Series X/S", "Nov 10,2026","$69.99", "Around $89.99 to $129.99 ", "Set within the fictional US state of Leonida, based on Florida, the story follows the romantic criminal duo of Jason Duval and Lucia Caminos as they navigate a massive open world predominantly featuring the Miami-inspired Vice City."), //Gta 6


  new Fields("TBD", "PlayStation 5, Xbox Series X|S, and Windows PC ", "September 8, 2026.","TBD", "TBD", " An asymmetrical stealth horror game where players can become the iconic masked killer Michael Myers or a civilian trying to survive the night in Haddonfield. "),  //halloween game


  new Fields("TBD", "PlayStation 5, Xbox Series X/S, and Windows PC ", "2026","TBD", "TBD", "Set a century after the events of the 2023 game, this standalone sequel is a brutal, dark fantasy action-RPG built in Unreal Engine 5 that features two fully explorable parallel worlds (Axiom and the deadlier Umbral realm), full shared co-op progression, and visceral combat."), //lords of the fallen

  new Fields("TBD", "PlayStation 5, Xbox Series X/S, and Windows PC.", "2026","TBD", "TBD", "In the chaos of World War II-era Occupied Paris, Captain America and Azzuri, the 1940s Black Panther, must form an uneasy alliance with two other heroes to stop a sinister Hydra plot that threatens to escalate the global conflict."), //Marvel 1943


  new Fields("TBD", "PlayStation 5, Xbox Series X/S, and Windows PC", "2026","TBD", "TBD", " Set in a politically volatile, near-future unified Korea, this narrative-driven, third-person action-adventure game follows a North Korean special forces operative and a K-pop star who uncover a dangerous conspiracy involving manipulated emotions and a mysterious terrorist group."),//mudang two hearts


  new Fields("TBD", " PlayStation 5 and Windows PC", "2026","TBD", "TBD", "This wuxia action-RPG is set in the Phantom World, a fictional universe that blends Chinese kungfu, steampunk, and occult elements, and follows the elite assassin Soul on a quest to uncover the truth behind his master's murder."), //phantom blade


  new Fields("TBD", " Xbox Series X/S and Windows PC, with a PlayStation 5 release confirmed for a post-launch date.", "2026","TBD", "TBD", " The highly fan-requested Horizon Festival is heading to the scenic and breathtaking landscapes of Japan, featuring a map that includes the vibrant Tokyo City and the iconic Mount Fuji. The cover art in your image is fan art created by concept artist Pietro Donzelli, not the final official cover"), //forza horrizon

  new Fields("TBD", " The game is a PlayStation Studios title and will launch as a console exclusive on PlayStation 5 (PS5) and PS5 Pro. A PC release might follow later, as was the case with Housemarque's previous game, Returnal.", "March 20, 2026","TBD", "TBD", "Developed by Housemarque (creators of Returnal), SAROS is an intense sci-fi action game set on the hostile alien planet Carcosa, where protagonist Arjun Devraj must uncover the truth behind a lost colony using unique projectile-absorbing shields."), //Saros


  new Fields("TBD", "PlayStation 5 console exclusive at launch; a PC release might follow later. ", "Fall 2026","TBD", "TBD", " Developed by Insomniac Games, this M-rated, single-player, action-adventure game tells an original, character-driven story about Logan's dark past and features brutal, fast-paced combat across various global locations, including Madripoor and Japan. "), //wolverine


  new Fields("TBD", "PlayStation 5, Xbox Series X/S, and Windows PC", "2026","TBD", "TBD", "An open-world, dark fantasy action-RPG from former The Witcher 3 developers, where players control Coen, a half-human, half-vampire trying to save his family within a 30-day time limit, with gameplay changing dramatically between day and night cycles.")//The blood of dawnwalker
];

// Function that fills all .flip-box-back elements
function applyFieldsToCards() {
  const backs = document.getElementsByClassName("card_info");

  for (let i = 0; i < backs.length && i < games.length; i++) {
    const game = games[i];
    backs[i].innerHTML = `
  <p><strong>Price:</strong> ${game.price}</p>
  <p><strong>Platform:</strong> ${game.platform}</p>
  <p><strong>Release Date:</strong> ${game.release_date}</p>
  <p><strong>Basic Edition Price:</strong> ${game.Basic_Edition}</p>
  <p><strong>Ultimate Edition Price:</strong> ${game.Ultimate_Edition}</p>
  <p class="desc"><strong>About:</strong> ${game.why}</p>
`;
  }
}

// Wait until the DOM is fully loaded before running
document.addEventListener("DOMContentLoaded", applyFieldsToCards);